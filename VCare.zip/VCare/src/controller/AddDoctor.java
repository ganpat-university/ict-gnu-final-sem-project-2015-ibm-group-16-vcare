package controller;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.Dao;
import model.Model;

public class AddDoctor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public AddDoctor() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fn= request.getParameter("firstName");
		String ln= request.getParameter("lastName");
		String email= request.getParameter("email");
		String pwd= request.getParameter("password");
		String dob= request.getParameter("dob");
		String no= request.getParameter("no");
		String height= request.getParameter("height");
		String weight= request.getParameter("weight");
		String gender= request.getParameter("gen");
		String license= request.getParameter("license");
		String speciality= request.getParameter("speciality");
		String page="";
		String sql="insert into doctor (first_name, last_name, email, password, dob, phone_no, height, weight, gender,license,speciality) values('"+fn+"','"+ln+"','"+email+"','"+pwd+"','"+dob+"','"+no+"','"+height+"','"+weight+"', '"+gender+"', '"+license+"', '"+speciality+"')";
		
		if(fn.equals("")||ln.equals("")||email.equals("")||pwd.equals("")||dob.equals("")||no.equals("")||height.equals("")||weight.equals("")||gender.equals("")||license.equals("")||speciality.equals(""))
		{
			page="adoctor.jsp?msg=failure";
		}
		else
		{
			try
			{
				Model m = new Model();
				m.setFn(fn);
				m.setLn(ln);
				m.setEmail(email);
				m.setPwd(pwd);
				m.setDob(dob);
				m.setNo(no);
				m.setHeight(height);
				m.setWeight(weight);
				m.setGender(gender);
				m.setLicense(license);
				m.setSpeciality(speciality);
				
				int i =Dao.register(m,sql);
				if(i!=0)
				{
					page="adoctor.jsp?msg=success";
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			response.sendRedirect(page);
		}
	}
}
